# [SEU NOME] – Memórias Escolares e Portfólio de Redações

Site de formatura do Ensino Médio. Publicado com GitHub Pages: [COLE AQUI O LINK]

## Estrutura
- `index.html` – página principal
- `css/style.css` – estilos
- `js/script.js` – conteúdo (memórias e 17 redações) e interatividade
- `assets/img/` – fotos (`perfil/` e `memorias/`)
